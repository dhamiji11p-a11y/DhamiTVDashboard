# Dhami TV Dashboard — Android TV project

यह शुरुआती Android Studio प्रोजेक्ट Mi Box 4K (Android TV 9.0) को ध्यान में रखकर बनाया गया है। इसमें वीडियो-जैसी नीली glass dashboard स्क्रीन, घड़ी/तारीख और remote-focusable ऐप कार्ड हैं।

## ज़रूरी बात
- यह **source project** है, पहले से बना/साइन किया हुआ APK नहीं।
- APK बनाने के लिए Windows/Mac/Linux कंप्यूटर पर Android Studio चाहिए।
- यह ऐप Android TV की app list में दिखने के लिए `LEANBACK_LAUNCHER` category शामिल करता है।
- यह अभी आपके Mi Box का default system launcher नहीं बदलता और Home बटन को अपने-आप replace नहीं करता।
- मौसम कार्ड अभी placeholder है; live weather/API और app-native launching अभी शामिल नहीं हैं। ऐप कार्ड वेबसाइट खोलने की कोशिश करते हैं।
- कोई system app disable/uninstall न करें।

## APK बनाने का तरीका
1. कंप्यूटर पर Android Studio इंस्टॉल करें: https://developer.android.com/studio
2. ZIP extract करें।
3. Android Studio में `DhamiTVDashboard` फ़ोल्डर Open करें।
4. Gradle sync पूरा होने दें। JDK/Gradle की माँग आए तो Android Studio का bundled JDK चुनें।
5. `Build > Build Bundle(s) / APK(s) > Build APK(s)` चुनें।
6. APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

## Mi Box 4K में इंस्टॉल
1. Mi Box: Settings > About > Build पर OK कई बार दबाएँ, जब तक Developer message न आए।
2. Settings > Device Preferences/System > Developer options में USB debugging या Network debugging उपलब्ध हो तो सक्षम करें। विकल्प Android version के अनुसार अलग हो सकते हैं।
3. APK को USB drive से कॉपी करें या भरोसेमंद local network transfer method का उपयोग करें।
4. APK खोलने के लिए file manager में “Install unknown apps” की अनुमति माँगी जाए तो केवल उसी file manager को अस्थायी रूप से अनुमति दें।
5. APK इंस्टॉल करके Apps सूची से **Dhami TV Dashboard** खोलें।

## Android Studio से सीधे चलाना (वैकल्पिक)
- Mi Box और कंप्यूटर एक ही Wi-Fi पर रखें।
- Developer options में Network/ADB debugging उपलब्ध होने पर उसे सक्षम करें और Android Studio/ADB से connect करें।
- Android Studio में Run दबाकर Mi Box चुनें।

## आगे के काम
- आपके Mi Box पर परीक्षण
- live weather
- वास्तविक Android apps को खोलने वाले intents
- launcher/default Home integration का सुरक्षित परीक्षण
